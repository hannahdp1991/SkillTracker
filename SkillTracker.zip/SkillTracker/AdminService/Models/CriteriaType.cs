﻿namespace AdminService
{
    public enum CriteriaType
    {
        AssociateId,
        AssociateName,
        SkillName
    }
}