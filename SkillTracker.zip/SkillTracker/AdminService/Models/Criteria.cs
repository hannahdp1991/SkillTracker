namespace AdminService.Models
{
    public class Criteria
    {
        public CriteriaType CriteriaType;

        public string CriteraValue;
    }
}